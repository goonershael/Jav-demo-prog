package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doGet(req, resp); 	// always delete this line as there s no such method ;
		
		//read data
		
		//set content type
		resp.setContentType("text/html");
		
		// process data
		
		//create actual content :HTML page
			//create a writer before gen. page
		PrintWriter pw = resp.getWriter();
		pw.println("<html>");
		pw.println("<body>");
		pw.println("This is body of th page");
		pw.println("</body>");
		pw.println("</html");
		
		
	
	
	
	}
}
