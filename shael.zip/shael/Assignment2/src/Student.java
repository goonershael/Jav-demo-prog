
public class Student {
	private String name;
	private int roll;
	private int totalM;
	private float percentage;
	public int getTotalM() {
		return totalM;
	}
	public void setTotalM(int totalM) {
		this.totalM = totalM;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}

	private int [] marks;
	public int[] getMarks() {
		return marks;
	}
	public void setMarks(int[] marks) {
		this.marks = marks;
	}

	private int total;
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public float getPercent() {
		return percent;
	}
	public void setPercent(float percent) {
		this.percent = percent;
	}

	private float percent;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	/*
	public int getSub1() {
		return sub1;
	}
	public void setSub1(int sub1) {
		this.sub1 = sub1;
	}
	public int getSub2() {
		return sub2;
	}
	public void setSub2(int sub2) {
		this.sub2 = sub2;
	}
	public int getSub3() {
		return sub3;
	}
	public void setSub3(int sub3) {
		this.sub3 = sub3;
	}
	public int getSub4() {
		return sub4;
	}
	public void setSub4(int sub4) {
		this.sub4 = sub4;
	}
	public int getSub5() {
		return sub5;
	}
	public void setSub5(int sub5) {
		this.sub5 = sub5;
	}
	*/
	
	public Student(){
		
	}
	
	public Student(String name, int roll, int [] marks){
		this.name = name;
		this.roll = roll;
		this.marks = marks;
		//this.sub1 = sub1;
		//this.sub2 = sub2;
		//this.sub3 = sub3;
		//this.sub4 = sub4;
		//this.sub5 = sub5;
	}
	
	public void display(){
		//System.out.println(name + "\t" + roll + "\t" + sub1 + "\t" + sub2 + "\t" + sub3 + "\t" + sub4 + "\t" + sub5);
	}
	
}
