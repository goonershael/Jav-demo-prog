
public class StudentData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Name\t RollNo. \t Subject1 Subject2 Subject 3 Subject 4 Subject 5 Total Percent");
		Student [] student;
		student = new Student[5];
		Logic log =  new Logic();
		
		int x =0;
		float y = 0;
		
		int [] marks = {23,90,89,78,67};
		int [] marks1 = {65, 79, 23, 78,61};
		int [] marks2 = {86, 29, 88, 68, 71};
		student[0] = new Student("Sahil", 123344, marks);
		student[1] =  new Student("nseit", 123354, marks1);
		student[2] =  new Student("Shael", 123454, marks2);
		for (int i = 0; i < student.length; i++){
			x = log.total(student[i]);
			System.out.println("Student name : " + student[i].getName());
			
			for (int j = 0; j <marks.length; j++){
				System.out.println("subject " +j + ":" + marks[j] );	
			}
			y = log.percent(x);
			System.out.println("Total Marks : " + x +"\n %age : " + y );
			student[i].setTotalM(x);
			student[i].setPercent(y);
		}
		System.out.println("Highest Marks : " + log.highMArks(student) );
	}
		
		/*
		x = log.total(student[1]);
		System.out.println("Stuednt name : " + student[1].getName() + "Roll  no : " + student[1].getRoll());
		
		for (int i = 0; i <marks1.length; i++){
			System.out.println("subject " +i + ":" + marks1[i] );
		}
		y = log.percent(x);
		System.out.println("Total Marks : " + x +"\n %age : " + y );
	}
	*/
	
}


	//{65, 79, 23, 78,61}, {86, 29, 88, 68, 71}, {90, 79, 82, 78, 61 }, {91, 59, 98, 77, 51}} ;
			/*for (int i = 0; i <student.length; i++){
				log.totalMarks(student[i]);
			}
			
			
			log.get
			
			for (int i = 0; i <student.length; i++){
				int total = log.totalMarks(Student student);
				student[i].setTotal(total);
				float percent = log.percentCalc(total);
				student[i].setPercent(percent);
			}
			
		 	student[0] = new Student ("Sahil", 12345, 96, 79, 88, 78, 81);
			student[1] = new Student ("raj", 12346, );
			student[2] = new Student ("Ankit", 12385, );
			student[3] = new Student ("Akhil", 12495, 90, 79, 82, 78, 61);
			student[4] = new Student ("Rohit", 12365, 91, 59, 98, 77, 51);
			*/