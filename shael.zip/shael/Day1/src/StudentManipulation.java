
public class StudentManipulation {
	public Student showStudent(Student student){
		/*
		 * Stub - can be written here  
		 * It doesnt has the business logic in it
		 */
		Student student2 =  null;
		student2 = student;
		//student2.setName("default");
		return student2; 
	}
		public Student showStudent(int rollNo){
			Student student=  null;
			student  = new Student(rollNo, "Shael", 45, 50, 60);
			return student; 
		}
		public int calculateTotal(Student student){
			int total = student.getSub1() + student.getSub2() + student.getSub3();
			return total;
		}	
		
		public float calPercentage(Student student){
			float percent  = 0.0f;
			percent = calculateTotal(student)/3f;
			return percent;
		
		
	}
}
