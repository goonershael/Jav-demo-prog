class TestClass2 {
	/*	Class -> To Hold the Data 
	 * 	or class manipulating the data - Abstraction : Business Logic  
	 * 	1. Data Members : The data that class is going to hold 
	 * 	2. Member Functions:  The function that is to be used to manipulate  the function 
	 * */
	public static void main(String[] args){
	/*
	 * Is not a member function - main is just a function 
	 * Entry point
	 */
		int i = 1232344;
		int a = 13123;
		System.out.println("Hello !!!");
		System.out.println("Value of i = " + i + "\nsum " + (i+a ));
	} 
	
}

class TestClass1 {
	/*	Class -> To Hold the Data 
	 * 	or class manipulating the data - Abstraction : Business Logic  
	 * 	1. Data Members : The data that class is going to hold 
	 * 	2. Member Functions:  The function that is to be used to manipulate  the function 
	 * */
	public static void main(String[] args){
	/*
	 * Is not a member function - main is just a function 
	 * Entry point
	 */
		int i = 1232344;
		int a = 13123;
		System.out.println("Hello !!!");
		System.out.println("Value of i = " + i + "\nsum " + (i+a ));
	} 
	
}
