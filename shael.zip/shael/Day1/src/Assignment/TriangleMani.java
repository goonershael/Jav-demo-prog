package Assignment;

public class TriangleMani {
	
	public float calcArea(Triangle tri){
		int side1 = tri.getSide1();
		int side2 = tri.getSide2();
		float area = 0.0f;
		area = (side1 * side2)/2;
		return area;
		
	}
}
