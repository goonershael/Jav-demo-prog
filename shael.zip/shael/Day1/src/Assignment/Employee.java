package Assignment;

public class Employee {
	
	private String ename;
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public int getB_sal() {
		return b_sal;
	}
	public void setB_sal(int b_sal) {
		this.b_sal = b_sal;
	}
	public int getG_sal() {
		return g_sal;
	}
	public void setG_sal(int g_sal) {
		this.g_sal = g_sal;
	}
	private int eid, b_sal, g_sal;
	
	public Employee(String ename, int eid, int b_sal){
		this.ename = ename;
		this.b_sal = b_sal;
		this.eid = eid;
		this.g_sal = g_sal;
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1 = new Employee("Sahil",237561,9000);
		emp_sal e = new emp_sal();
		
		System.out.println("Gross salary " + e.calcuateSalary(e1));
		Employee e2 = new Employee("Akhil",237560,20000);
		emp_sal es = new emp_sal();
		System.out.println("Gross salary " + e.calcuateSalary(e2));
		Employee e3 = new Employee("Raj ",237521,11000);
		emp_sal e_sal = new emp_sal();
		System.out.println("Gross salary " + e.calcuateSalary(e3));
		e.calcuateSalary(e3);
	}

}
