
public class TestStudentClass1 {
	public static void main(String[]  args){
		Student mystudent = new Student (92384728, "Shael K", 23, 45, 23);
		
		StudentManipulation m = new StudentManipulation();
		Student s = m.showStudent(mystudent);
		System.out.println(s.getRollNo() + "\t"+ s.getName());
		
		int total = m.calculateTotal(mystudent);
		System.out.println("Total Marks : " + total);
		
		System.out.println("%age Marks obtained "+ m.calPercentage(mystudent));
	}
}
