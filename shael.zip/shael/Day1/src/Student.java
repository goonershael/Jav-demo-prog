
public class Student {
	private int rollNo;
	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSub1() {
		return sub1;
	}

	public void setSub1(int sub1) {
		this.sub1 = sub1;
	}

	public int getSub2() {
		return sub2;
	}

	public void setSub2(int sub2) {
		this.sub2 = sub2;
	}

	public int getSub3() {
		return sub3;
	}

	public void setSub3(int sub3) {
		this.sub3 = sub3;
	}

	private String  name;
	private int sub1, sub2, sub3;
	
	public void display(){
		System.out.println("roll No. "+rollNo + "\nName : " +name + "\nsubject 1 marks : "+sub1 + "\nsubject 2 marks : " + sub2 + "\nSubject 3 marks : " + sub3);
	}
	
	public  Student(){
		name = "Sahil";
		rollNo = 92384728;
		sub1 = 50;
		sub2 = 70;
		sub3 = 100;
	}
	
	public  Student(int rollNo, String name, int sub1, int sub2, int sub3){
		this.name = name;
		this.rollNo = rollNo;
		this.sub1 = sub1;
		this.sub2 = sub2;
		this.sub3 = sub3;
	}
	
	public static void main(String [] args){	
		Student  s = new Student();
		//s.setvalues();
		s.display();
		
		s = new Student(32781873, "Shael", 80,32 , 74);
		//s.setvalues(32781873, "Shael", 80,32 , 74);
		s.display();
		s.sub1 = 20;
		System.out.println("changed data ");
		s.display();
	}
}
