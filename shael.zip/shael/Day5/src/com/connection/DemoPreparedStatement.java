package com.connection;

import java.sql.Connection;
import com.connection.MyConnection;

public class DemoPreparedStatement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection connection = MyConnection.setConnection();
		System.out.println("Connection established - SUCCESS!!!");
		
		MyConnection.closeConnection();
		System.out.println("Connection Closed Successfully!!!");
		
	}

}
