import java.util.ArrayList;
import java.util.List;

public class DemoArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List list = new ArrayList();
		list.add(10);	// same as new Integer (30)
		list.add(20);
		list.add(30);
		list.add(1000);
		
		System.out.println(list.size());
		list.add(60);
		list.add(2);
		System.out.println(list.size());
		System.out.println(list);
		list.remove(2);
		System.out.println(list);

		list.remove(new Integer(2));
		System.out.println(list);
		
		list.set(3, 0);
		list.remove(0);
		list.add(0, 3300);
		System.out.println(list);
		
	}

}
