package com.comparators;

import cm.nseit.pojo.*;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;
import com.comparators.PersonComparator;


public class DemoComparator implements Comparator<Person> {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Person>person = new TreeSet(new PersonComparator());
		person.add(new Person());
		person.add(new Person ("shael", 24, 11));
		person.add(new Person ("shael", 24, 2));
		person.add(new Person ("aditya", 14, 1));
		person.add(new Person());
		System.out.println(person);
		System.out.println("Size : " + person.size());
	}

	@Override
	public int compare(Person person1, Person person2) {
		// TODO Auto-generated method stub
		 return person1.getAdh_num()-person2.getAdh_num();
	}

}
