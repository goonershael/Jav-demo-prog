package com.comparators;

import java.util.Comparator;

import cm.nseit.pojo.Person;

public class PersonComparator implements Comparator<Person> {
	@Override
	public int compare(Person person1, Person person2) {
		// TODO Auto-generated method stub
		return person1.getAge()-person2.getAge();
	}
}
