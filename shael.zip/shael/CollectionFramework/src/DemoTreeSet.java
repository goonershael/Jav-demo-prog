import java.util.Set;
import java.util.TreeSet;

import cm.nseit.pojo.Person;

public class DemoTreeSet {
	
	public static void main(String[] args) {
		Set<Person>person = new TreeSet<>();
		person.add(new Person());
		person.add(new Person ("shael", 24, 37891273));
		person.add(new Person ("shael", 24, 37891273));
		person.add(new Person ("aditya", 14, 37221273));
		person.add(new Person());
		System.out.println(person);
		System.out.println("Size : " + person.size());
		
	}
}
