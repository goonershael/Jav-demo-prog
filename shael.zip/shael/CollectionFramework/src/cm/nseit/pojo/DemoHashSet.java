package cm.nseit.pojo;

import java.util.HashSet;
import java.util.Set;

public class DemoHashSet {
	public  static void  main (String [] args) {
		// TODO Auto-generated method stub
		/*Set<Integer>set = new HashSet<>();
		set.add(1);
		set.add(100);
		set.add(1000);
		
		System.out.println("size : " + set.size());
		System.out.println(set);
		
		set.remove(1);
		System.out.println("size : " + set.size());
		System.out.println(set);
		*/
		Set<Person> person = new HashSet<>();
		person.add(new Person());
		person.add(new Person ("shael", 24, 37891273));
		person.add(new Person ("shael", 24, 37891273));
		person.add(new Person ("aditya", 14, 37221273));
		person.add(new Person());
		System.out.println(person);
		System.out.println("Size : " + person.size());
	}
}
