
public class DataConv {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String age  = "20";
		int age_prim = Integer.parseInt(age);
		if (age_prim >= 20){
			System.out.println("Ok");
		}
		
		Integer data  = 10;
		int x = 0 ;
		x = data ;
		System.out.println("x : " + x);
		
		Double d = 20.20d;
		x=d.intValue();
		System.out.println("Double va "+ d  + " x: " + x);
		
	}

}
