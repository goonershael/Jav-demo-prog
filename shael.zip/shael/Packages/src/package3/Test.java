package package3;

import package1.MyClass;

public class Test {
	public void test(){
		
	}
	public static void main(String[] args){
		
	}
}
