package package1;

public class testMyClass {
	public void testAdd(){
		new MyClass().add();
		
	}
}
