
public class Person {
	private String name;
	private int age;
	public Person (){
		System.out.println("default");
	}
	public Person(String name, int age){
		this.age = age;
		this.name  = name;
	}
	
	 public void show(){
	 
		System.out.println("Emp Name : " + name +" Emp Age : "+age);
	}
	 @Override
	 public String toString(){
		 return name+" age(" + age+")";
	 }
	 
	 @Override
	 public boolean equals (Object object ){
		 Person person=(Person)object;
		 return this.name.equals(person.name);
	 }
	
}
