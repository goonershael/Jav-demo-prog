
public class Demostatic {
	private int data;
	private static int count;
	
	public Demostatic(){
		data = 1000;
		count++;
	}
	static {
		count  = 1;
		
	}
	public void display(){
		System.out.println("daata : " + data+ "\tcounter : " + count);
	}
	
	public static void showCount(){
		System.out.println("Counter  : " + count);
	}
	
	public static void main(String [] args){
		showCount();
		Demostatic obj = new Demostatic();
		obj.display();
		Demostatic obj1 = new Demostatic();
		obj1.display();
		
		obj.showCount();
	}
}

class Demo1{
	public static void main(String[] args){
		Demostatic.showCount();
	}
}