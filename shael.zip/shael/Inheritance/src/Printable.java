
public interface Printable {
	public abstract void print();
	public static final int x = 10;
	
}

class Demo {
	void display(){
		Printable printable = new Printable() {
			
			@Override
			public void print() {
				// TODO Auto-generated method stub
				System.out.println("Printing");
			}
		};
		printable.print();
	}
	public static void main (String[] args){
		Demo demo = new Demo();
		demo.display();
	}

	
	void show(){
		//Printable p=()-> {System.out.println();};}
		//p.print();
	}
}



class PrintImpl implements Printable{
	public void print(){
		
	}
}
