package com.dao;

import java.util.List;

import com.pojo.Student;

public interface StudentDAO {
	public int addStudent(Student student);
	public Student updateStudent (int rollno, String addr);
	public int deleteStudent(int rollno);
	public Student findByRollno(int rollno);
	List<Student> findByName(String name);
	List<Student>findByAddress(String addr);
	
}
