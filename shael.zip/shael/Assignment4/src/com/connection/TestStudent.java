package com.connection;

import com.pojo.Student;
import com.dao.StudentDAOImpl;

import java.util.Scanner;

public class TestStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student = null;
		StudentDAOImpl sdi = null;
		System.out.println("WELCOME TO NSEIT \nPlease enter choice \n1. add\n2. update\n3. delete\n4. find by rollno\n5. find by address\n6. find by name");
		Scanner scanner = new Scanner(System.in);
		int choice = scanner.nextInt();
		if(choice  == 1){
			String name, addr;
			int rollno, total;
			System.out.print("enter name : ");
			name  = scanner.next();
			System.out.print("enter rollno : ");
			rollno  = scanner.nextInt();
			System.out.print("enter Address : ");
			addr  = scanner.next();
			System.out.print("enter Marks : ");
			total  = scanner.nextInt();
			student = new Student(name, rollno, addr, total );
			//System.out.println(student);
			int x;
			sdi = new StudentDAOImpl();
			x = sdi.addStudent(student);
			if (x != 0){
				System.out.println("Record Added Successfully");
			}
		}else if(choice  == 2){
			//sdi.addStudent(student);
			String addr;
			int rollno;
			System.out.print("enter rollno : ");
			rollno  = scanner.nextInt();
			System.out.print("enter new  Address : ");
			addr  = scanner.next();
			sdi = new StudentDAOImpl();
			student = sdi.updateStudent(rollno, addr);
			System.out.println(student);
			System.out.println("Record Updated successfully");
		}else if(choice  == 3){
			int rollno, rows;
			rollno = scanner.nextInt();
			System.out.print("enter rollno : ");
			rollno  = scanner.nextInt();
			sdi = new StudentDAOImpl();
			rows =sdi.deleteStudent(rollno);
			if (rows != 0){
				System.out.println("Record Deleted successfully");
			}
			
		}else if(choice  == 4){
			int rollno;
			
			System.out.print("enter rollno : ");
			rollno = scanner.nextInt();
			sdi = new StudentDAOImpl();
			student = sdi.findByRollno(rollno);
			System.out.println(student);
			System.out.println("Record Detected successfully");
		}else if(choice  == 5){
			//sdi.addStudent(student);
		}else if(choice  == 6){
			//sdi.addStudent(student);
		}else{
			System.out.println("Invalid choice");
		}
	}

}
