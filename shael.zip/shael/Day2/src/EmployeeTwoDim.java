
public class EmployeeTwoDim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][] arr = new int [3][3];
		arr[0][0] =0;
		arr[0][1] =0;
		arr[0][2] =0;
		arr[1] = new int [1];
		arr[1][0] =0;
		//arr[1][1] =11;
		//arr[1][2] =12;
		arr[2] = new int [2];
		arr[2][0] =0;
		arr[2][1] =0;
		//arr[2][2] =0;

		for (int i = 0; i<arr.length; i++){
			for (int j = 0; j<arr[i].length; j++){
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
		
		for (int[] arr1 : arr){
			for (int j: arr1){
				System.out.print(j+"\t");
			}
			System.out.println();
		}
	}

}
