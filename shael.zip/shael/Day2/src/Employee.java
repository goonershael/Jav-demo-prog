
public class Employee {
		
		private String ename;
		private int eid, b_sal, g_sal;
		public String getEname() {
			return ename;
		}
		public void setEname(String ename) {
			this.ename = ename;
		}
		public int getEid() {
			return eid;
		}
		public void setEid(int eid) {
			this.eid = eid;
		}
		public int getB_sal() {
			return b_sal;
		}
		public void setB_sal(int b_sal) {
			this.b_sal = b_sal;
		}
		public int getG_sal() {
			return g_sal;
		}
		public void setG_sal(int g_sal) {
			this.g_sal = g_sal;
		}
		
		
		public Employee(String ename, int eid, int b_sal){
			this.ename = ename;
			this.b_sal = b_sal;
			this.eid = eid;
		
		}
		public Employee(){
			 ename = null;
			 b_sal = 0 ;
			 eid = 0 ;
		
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
